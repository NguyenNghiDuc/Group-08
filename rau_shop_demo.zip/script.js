document.querySelectorAll('.add').forEach(btn=>{
    btn.addEventListener('click', ()=>{
        let countEl = document.getElementById('cartCount');
        let count = parseInt(countEl.textContent || '0', 10);
        countEl.textContent = count + 1;
        btn.textContent = 'Đã thêm';
        setTimeout(()=> btn.textContent = 'Thêm vào giỏ', 1200);
    });
});